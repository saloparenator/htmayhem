/*******************************************************************************************************/
/*                                                                                                     */
/*  Fichier....................:  background.js                                                        */
/*  Type.......................:  Classe Javascript                                                    */
/*  Titre......................:  background          .                                                */
/*  Auteur.....................:  Martin Robinson                                                      */
/*                                Thibault Podevin                                                     */
/*                                Alexis Caron                                                         */
/*                                Alfredo Toyo                                                         */
/*  Copyright..................:  C�gep de Sherbrooke, all left free                                   */
/*  Date de cr�ation...........:  2013-10-19                                                           */
/*  Date de mise en production.:  2013-11-04                                                           */
/*                                                                                                     */
/*******************************************************************************************************/
/*  MODIFICATIONS                                                                                      */
/*  DATE       : PAR               : DESCRIPTION DES MODIFICATIONS                                     */
/*                                                                                                     */
/*******************************************************************************************************/
/*                                                                                                     */
/*  - Gestion de la phisique sur des points                                                            */
/*                                                                                                     */
/*  En entr�e: RIEN                                                                                    */
/*                                                                                                     */
/*  En sortie: Document XHTML dynamique envoyer par mail.                                              */
/*                                                                                                     */
/*******************************************************************************************************/

/*******************************************************************************************************/
function Gazon(ecran_largeur, ecran_hauteur, color, tempsSecond)
/*******************************************************************************************************/
//objet Gazon
//cet objet simule la moindre brindille de gazon ainsi que les insectes et la ros�e
//c'est un simple rectangle d'une couleur donn�e qui devien sombre la nuit
//contructeur:
//  ecran_largeur   nombre largeur en pixel de la surface de dessin
//  ecran_hauteur   nombre hauteur en pixel de la surface de dessin
//  color           couleur � donn�es au gazon (selon la saison)
//  tempsSecond     heur de la journ�e en seconde depuis minuit
/*******************************************************************************************************/
{
  this.hauteur = 100;
  this.iteration = (tempsSecond%43200);
  this.est_jour = tempsSecond/43200 > 1;
  this.rect_gazon_alpha = (this.iteration/43200)-0.3;

  this.elemGazon = document.createElementNS('http://www.w3.org/2000/svg',"use");
  this.elemGazon.setAttributeNS("http://www.w3.org/1999/xlink", "xlink:href", "#gazon");

  this.rect_gazon = document.getElementById("rect_gazon");
  this.rect_gazon_noir = document.getElementById("rect_gazon_noir");
   
  this.rect_gazon.setAttribute("x",0);
  this.rect_gazon.setAttribute("y",ecran_hauteur-this.hauteur);
  this.rect_gazon.setAttribute("width",ecran_largeur);
  this.rect_gazon.setAttribute("height",this.hauteur);
  this.rect_gazon.setAttribute("fill",color);

  this.rect_gazon_noir.setAttribute("x",0);
  this.rect_gazon_noir.setAttribute("y",ecran_hauteur-this.hauteur);
  this.rect_gazon_noir.setAttribute("width",ecran_largeur);
  this.rect_gazon_noir.setAttribute("height",this.hauteur);
  
  /*--------------------------------------------------------*/  
  this.iterate = function()
  /*--------------------------------------------------------*/
  //avanc� d'une seconde dans la journ�e
  //devien de plus en plus clair vers midi
  //devien de plus en plus sombre vers minuit 
  /*--------------------------------------------------------*/  
  {
    if(this.iteration < 43200)
    {
      if(this.est_jour == true)
      {
        this.rect_gazon_alpha += 0.000023148;
      }
      else
      {
        this.rect_gazon_alpha -= 0.000023148;
      }
      this.iteration++;
    }
    else
    {
      if(this.est_jour == true)
        this.est_jour = false;
      else
        this.est_jour = true;
      this.iteration = 0;
    }
    this.rect_gazon_noir.setAttribute("fill","rgba(0,0,0,"+this.rect_gazon_alpha+")");
  }
}

/*******************************************************************************************************/
function Ciel(ecran_largeur, ecran_hauteur, tempsSecond)
/*******************************************************************************************************/
//Objet ciel
//un arriereplan d�call� vers le bas qui tourne sur lui meme selon l'heur de la journ�
//comme �a le jour et la nuit se succede et se cache derri�re l'horison
//  ecran_largeur   nombre largeur en pixel de la surface de dessin
//  ecran_hauteur   nombre hauteur en pixel de la surface de dessin
//  tempsSecond     heur de la journ�e en seconde depuis minuit
/*******************************************************************************************************/
{
  this.centre_x = ecran_largeur*0.5;
  this.centre_y = ecran_hauteur;
  this.ciel = document.getElementById("ciel");
  this.angle = tempsSecond*(Math.PI/43200);
  this.elemCiel = document.createElementNS('http://www.w3.org/2000/svg',"use");
  this.elemCiel.setAttributeNS("http://www.w3.org/1999/xlink", "xlink:href", "#ciel");

  var couleur_ciel = document.getElementById("couleur-ciel");
  var lune = document.getElementById("lune");
  var soleil = document.getElementById("soleil");
  lune.setAttribute("transform","translate(0,"+((this.centre_x)-20)+")");
  soleil.setAttribute("transform","translate(0,"+((this.centre_x)-20)*-1+")");
  couleur_ciel.setAttribute("transform","rotate(90)");

  var rect_ciel = document.getElementById("rect_ciel");
  rect_ciel.setAttribute("x",ecran_largeur*-2);
  rect_ciel.setAttribute("y",ecran_hauteur*-2);
  rect_ciel.setAttribute("width",ecran_largeur*4);
  rect_ciel.setAttribute("height",ecran_hauteur*4);

  /*--------------------------------------------------------*/  
  this.iterate = function()
  /*--------------------------------------------------------*/
  //avancer d'une seconde
  //un tour complet en 24 heur  
  /*--------------------------------------------------------*/  
  {
    this.angle += Math.PI/43200;

    var cos_angle = -1*Math.cos(this.angle);
    var sin_angle = -1*Math.sin(this.angle);

    this.ciel.setAttribute('transform',"matrix("+cos_angle+","+sin_angle+","+(-1*sin_angle)+","+cos_angle+","+this.centre_x+","+this.centre_y+")");
  }
}

/*******************************************************************************************************/
function ArrierePlan(ecran_largeur, ecran_hauteur, color, tempsSecond)
/*******************************************************************************************************/
//objet arrierePlan
//objet qui encapsul le ciel et le gazon
//  ecran_largeur   nombre largeur en pixel de la surface de dessin
//  ecran_hauteur   nombre hauteur en pixel de la surface de dessin
//  color           couleur � donn�es au gazon (selon la saison)
//  tempsSecond     heur de la journ�e en seconde depuis minuit
/*******************************************************************************************************/
{
  this.ciel = new Ciel(ecran_largeur, ecran_hauteur, tempsSecond);
  this.gazon = new Gazon(ecran_largeur, ecran_hauteur, color, tempsSecond);

  /*--------------------------------------------------------*/    
  this.afficherA = function (GrpSVGdom)
  /*--------------------------------------------------------*/
  //ajouter l'element svg au groupe svg affich�
  /*--------------------------------------------------------*/  
  {
    GrpSVGdom.appendChild(this.ciel.elemCiel);
    GrpSVGdom.appendChild(this.gazon.elemGazon);
  }

  /*--------------------------------------------------------*/    
  this.iterate = function ()
  /*--------------------------------------------------------*/
  //avanc� d'une seconde
  /*--------------------------------------------------------*/  
  {
    this.ciel.iterate();
    this.gazon.iterate();
  }
}
