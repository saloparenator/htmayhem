/*******************************************************************************************************/
/*                                                                                                     */
/*  Fichier....................:  meteo.js                                                             */
/*  Type.......................:  Document js                                                          */
/*  Titre......................:  meteo                                                                */
/*  Auteur.....................:  2013 Alfredo Toyo, C�gep de Sherbrooke, all left free                */
/*  Auteur.....................:  2013 Thibault Podevin, C�gep de Sherbrooke, all left free            */
/*  Auteur.....................:  2013 Martin Robinson, C�gep de Sherbrooke, all left free             */
/*  Auteur.....................:  2013 Alexis Caron, C�gep de Sherbrooke, all left free                */
/*  Date de cr�ation...........:  2013-11-09                                                           */
/*  Date de mise en production.:  2013-12-20                                                           */
/*                                                                                                     */
/*******************************************************************************************************/
/*  MODIFICATIONS                                                                                      */
/*  DATE       : PAR               : DESCRIPTION DES MODIFICATIONS                                     */
/*                                                                                                     */
/*******************************************************************************************************/
/*                                                                                                     */
/*  - Carnet d'adresses.                                                                               */
/*                                                                                                     */
/*  En entr�e: RIEN                                                                                    */
/*                                                                                                     */
/*  En sortie: Document XHTML dynamique.                                                               */
/*                                                                                                     */
/*******************************************************************************************************/

/*******************************************************************************************************/
//constante
/*******************************************************************************************************/

const collisionSolHauteur = 80;

/*******************************************************************************************************/
//objet
/*******************************************************************************************************/

/*******************************************************************************************************/
function Nuage(ecranLargeur, ecranHauteur, x, y, elementGoutte, lourd, elemsSon)
/*******************************************************************************************************/
//Objet nuage
//cet objet anime un nuage � l'�cran et generer les averses (pluie, neige) qui proviennent de ce dernier
//
//construction
//	ecranLargueur     un nombre qui d�termine la largeur de la surface de dessin
//	ecranHauteur	  un nombre qui d�termine la hauteur de la surface de dessin
//	x,y				  coordonn� X,Y de d�part du nuage
//  lourd			  boolean qui d�termine si les averses vont zigzaguer comme des feuilles au vent ou pas
//	elementGoutte	  chaine de character contenant le ID de l'�l�ment SVG � dupliquer pour generer les averses
//	elemsSon		  Array d'objet DOM qui contient les diff�rents effet sonore � activer selon les �venements
/*******************************************************************************************************/
{
  //propri�t�
  this.elemNuage = document.createElementNS('http://www.w3.org/2000/svg',"use");
  this.elemNuage.setAttributeNS("http://www.w3.org/1999/xlink", "xlink:href", "#nuage");
  this.ecran_largeur = ecranLargeur;
  this.ecran_hauteur = ecranHauteur;
  this.sol_hauteur = ecranHauteur - collisionSolHauteur;
  this.x = x;
  this.y = y;
  this.arrayGoutteFlocon = [];
  this.elemsSon = elemsSon;
  this.elemMeteo = null;
  this.elementGoutte = elementGoutte;
  
  /*==========================================================*/
  this.deplacementNuage = function(vent)
  /*==========================================================*/
  //bouger le nuage de droit � gauche selon le vent
  //entr�e:
  //  vent   en nombre
  /*==========================================================*/
  {
    this.x += vent;
    this.elemNuage.setAttribute("transform","translate("+this.x+"," +this.y+")"); 
  
    if(this.x > this.ecran_largeur+50)
    {
      this.x = -49;
      this.elemNuage.setAttribute("transform","translate("+this.x+"," +this.y+")"); 
    }
  
    if(this.x < -50)
    {
      this.x = this.ecran_largeur+49;
      this.elemNuage.setAttribute("transform","translate("+this.x+"," +this.y+")");
    }
  };
  
  /*==========================================================*/
  this.afficherA = function(elemGroupeSvg)
  /*==========================================================*/
  //inserer lelement SVG du nuage dans la surface de dessin
  //egalement stocker la r�f�rence vers l'�l�ment pour le g�n�rateur d'averse
  //entree:
  //  elemGroupeSvg   objet DOM qui repr�sente la couche affich�
  /*==========================================================*/
  {
    elemGroupeSvg.appendChild(this.elemNuage);
    this.elemMeteo = elemGroupeSvg;
  };
  
  /*==========================================================*/
  this.degoute = function()
  /*==========================================================*/
  //methode de generation d'averse
  //cette m�thode cr�era un element SVG et un objet de collision
  //repr�sentant une goute d'eau ou un flocon de neige
  //ce dernier sera inserer dans une array pour les futures mis � jours
  /*==========================================================*/
  {
    var largeurCloud = 50;
    var hauteurCloud = 20;
    var debut = Number(this.x)-largeurCloud*0.5;
    var fin = largeurCloud;
    var x = Math.floor((Math.random()*fin)+debut);
    var y = Number(hauteurCloud) + Number(this.y);
    var goute = new point(0,x,y,0,10,null,null,null);
	
    ajoutePhysiqueAuPoint(goute);
    if (lourd==false)
      goute.moveTo(0,1);
    ajoute_element_svg_au_point(goute,this.elementGoutte);
    if (this.elemMeteo != null)
      this.elemMeteo.appendChild(goute.elemSVG); 
    this.arrayGoutteFlocon.push(goute);
	
    return goute;
  };

  /*==========================================================*/
  this.tombe = function (gravite, vent, arbre)
  /*==========================================================*/
  //methode de mise � jours des averses
  //cette m�thode filtre l'array de goutte ou de flocon
  //et g�n�rer un nouvelle array de goutte ou de flocon
  //seulement ceux qui n'ont pas fait de colision seront ins�rer dans le nouvelle array
  //les �l�ments sont mis � jours selon la gravit� et le vente
  //les �l�ments disparaissent quand ils entrent en collision avec les feuille d'arbre ou le sol
  //entree:
  //  gravite nombre
  //  vent nombre
  //  arbre  objet qui contient l'arbre
  /*==========================================================*/
  {
    var yiel = [];		//yeild(terme d'iteration fonctionnel) moin le D car ce mot est r�serv�
	
    for(var i in this.arrayGoutteFlocon)
    {
      this.arrayGoutteFlocon[i].force(vent, gravite*10);
      if (this.arrayGoutteFlocon[i].VaRentrerEnCollisionAvecLeSol(this.sol_hauteur))
      {
        var numSon = Math.floor(Math.random() * this.elemsSon.length);
        this.elemsSon[numSon].currentTime = 0;
        this.elemsSon[numSon].play();
        this.arrayGoutteFlocon[i].annuleForce();
        this.elemMeteo.removeChild(this.arrayGoutteFlocon[i].elemSVG);
      }
      else if (lourd == true && arbre.collisionFeuille(this.arrayGoutteFlocon[i]))
      {
        var numSon = Math.floor(Math.random() * this.elemsSon.length);
        this.elemsSon[numSon].currentTime = 0;
        this.elemsSon[numSon].play();
        this.arrayGoutteFlocon[i].annuleForce();
        this.elemMeteo.removeChild(this.arrayGoutteFlocon[i].elemSVG);
      }
      else
      {
        yiel.push(this.arrayGoutteFlocon[i]);
      }
      
      if (lourd==false)
        this.arrayGoutteFlocon[i].ajoute_deplacement_non_lineeaire(true, true, false);  //<====hivers
      this.arrayGoutteFlocon[i].move();
      this.arrayGoutteFlocon[i].MiseAJour_element_svg();
    }
    this.arrayGoutteFlocon=yiel;
  };
}

/*******************************************************************************************************/
function Polenisateur(ecranLargeur, ecranHauteur, elemsSon)
/*******************************************************************************************************/
//Objet g�n�rateur de polene
//contrairement au nuage le polene arrive de droite ou de gauche de l'�cran selon le vente
//
//construction
//	ecranLargueur     un nombre qui d�termine la largeur de la surface de dessin
//	ecranHauteur	  un nombre qui d�termine la hauteur de la surface de dessin
//	elemsSon		  Array d'objet DOM qui contient les diff�rents effet sonore � activer selon les �venements
/*******************************************************************************************************/
{

  this.elemNuage = document.createElementNS('http://www.w3.org/2000/svg',"use");
  this.ecran_largeur = ecranLargeur;
  this.ecran_hauteur = ecranHauteur;
  this.sol_hauteur = ecranHauteur - collisionSolHauteur;
  this.arrayPollen = [];
  this.elemsSon = elemsSon;
  this.elemMeteo=null;
  this.elementGoutte = "poleine";
  this.polenSource = 0;
  
  /*==========================================================*/
  this.afficherA = function(elemGroupeSvg)
  /*==========================================================*/
  //stocker la r�f�rence vers l'�l�ment pour le g�n�rateur d'averse
  //entree:
  //  elemGroupeSvg   objet DOM qui repr�sente la couche affich�
  /*==========================================================*/
  {
    //elemGroupeSvg.appendChild(this.elemNuage);
    this.elemMeteo = elemGroupeSvg;
  };
  
  /*==========================================================*/
  this.degoute = function()
  /*==========================================================*/
  //methode de generation d'averse
  //cette m�thode cr�era un element SVG et un objet de collision
  //repr�sentant une goute d'eau ou un flocon de neige
  //ce dernier sera inserer dans une array pour les futures mis � jours
  /*==========================================================*/
  {
    var debut = 0;
    var fin = Number(this.ecran_hauteur)*0.8;
    var y = Math.floor((Math.random()*fin)+debut);
    var x = this.polenSource;
    
    var goute = new point(0,x,y,0,10,null,null,null);
    ajoutePhysiqueAuPoint(goute);
    goute.moveTo(1,0);
    ajoute_element_svg_au_point(goute,this.elementGoutte);
    if (this.elemMeteo != null)
      this.elemMeteo.appendChild(goute.elemSVG);
      
    this.arrayPollen.push(goute);
    return goute;
  };

  /*==========================================================*/
  this.tombe = function (gravite, vent, arbre)
  /*==========================================================*/
  //methode de mise � jours des averses
  //cette m�thode filtre l'array de polene
  //et g�n�rer un nouvelle array de polene
  //seulement ceux qui n'ont pas fait de colision seront ins�rer dans le nouvelle array
  //les �l�ments sont mis � jours selon la gravit� et le vente
  //les �l�ments disparaissent quand ils entrent en collision avec les feuille d'arbre ou le sol
  //entree:
  //  gravite nombre
  //  vent nombre
  //  arbre  objet qui contient l'arbre
  /*==========================================================*/
  {
    this.polenSource = (vent>1?1:this.ecran_largeur-1);
    var yiel = [];
    for(var i in this.arrayPollen)
    {
      this.arrayPollen[i].force(vent*1, 0);
      if (this.arrayPollen[i].x > this.ecran_largeur || this.arrayPollen[i].x < 0)
      {
        var numSon = Math.floor(Math.random() * this.elemsSon.length);
        this.elemsSon[numSon].currentTime = 0;
        this.elemsSon[numSon].play();
        this.arrayPollen[i].annuleForce();
        this.elemMeteo.removeChild(this.arrayPollen[i].elemSVG);
      }
      else if (arbre.collisionFeuille(this.arrayPollen[i]))
      {
        var numSon = Math.floor(Math.random() * this.elemsSon.length);
        this.elemsSon[numSon].currentTime = 0;
        this.elemsSon[numSon].play();
        this.arrayPollen[i].annuleForce();
        this.elemMeteo.removeChild(this.arrayPollen[i].elemSVG);
      }
      else
      {
        yiel.push(this.arrayPollen[i]);
      }

      this.arrayPollen[i].ajoute_deplacement_non_lineeaire(true, false, true);
      this.arrayPollen[i].move();
      this.arrayPollen[i].MiseAJour_element_svg();
    }
    this.arrayPollen=yiel;
  };  
}

/*******************************************************************************************************/
function FeuilleTombante(ecranLargeur, ecranHauteur, elemsSon)
/*******************************************************************************************************/
//Objet g�n�rateur de feuille tombante
//
//construction
//	ecranLargueur     un nombre qui d�termine la largeur de la surface de dessin
//	ecranHauteur	  un nombre qui d�termine la hauteur de la surface de dessin
//	elemsSon		  Array d'objet DOM qui contient les diff�rents effet sonore � activer selon les �venements
/*******************************************************************************************************/
{

  this.elemNuage = document.createElementNS('http://www.w3.org/2000/svg',"use");
  this.ecran_largeur = ecranLargeur;
  this.ecran_hauteur = ecranHauteur;
  this.sol_hauteur = ecranHauteur - collisionSolHauteur;
  this.arrayFeuilleTombante = [];
  this.elemsSon = elemsSon;
  this.elemMeteo=null;
  
  this.elementGoutte = "feuillerouge";

  this.arbre = null;
  
  /*==========================================================*/
  this.afficherA = function(elemGroupeSvg)
  /*==========================================================*/
  //stocker la r�f�rence vers l'�l�ment pour le g�n�rateur d'averse
  //entree:
  //  elemGroupeSvg   objet DOM qui repr�sente la couche affich�
  /*==========================================================*/
  {
    this.elemMeteo = elemGroupeSvg;
  };
  
  /*==========================================================*/
  this.degoute = function(arbre)
  /*==========================================================*/
  //methode de generation de feuille tombante
  //cette m�thode cr�era un element SVG et un objet de collision
  //repr�sentant une feuille tombante
  //ce dernier sera inserer dans une array pour les futures mis � jours
  //la source est d�termin� par un choix al�atoir de feuille d�j�
  //existante dans l'arbre
  /*==========================================================*/
  {
    var debut = 0;
    var fin = Number(this.ecran_largeur);
    var i = Math.floor(Math.random()*arbre.feuille.length);
    var feuille = arbre.feuille[i];
    var x = feuille.x;
    var y = feuille.y;
    
    var goute = new point(0,x,y,0,10,null,null,null);
    ajoutePhysiqueAuPoint(goute);
    goute.moveTo(0,1);
    
    ajoute_element_svg_au_point(goute,this.elementGoutte);
    goute.tourne(feuille.angle);

    if (this.elemMeteo != null)
      this.elemMeteo.appendChild(goute.elemSVG);

    this.arrayFeuilleTombante.push(goute);
    var numSon = Math.floor(Math.random() * this.elemsSon.length);
    this.elemsSon[numSon].currentTime = 0;
    this.elemsSon[numSon].play();

    return goute;
  };

  /*==========================================================*/
  this.tombe = function (gravite, vent)
  /*==========================================================*/
  //methode de mise � jours des feuilles tombante
  //cette m�thode filtre l'array de feuille
  //et g�n�rer un nouvelle array de feuille
  //seulement ceux qui n'ont pas fait de colision seront ins�rer dans le nouvelle array
  //les �l�ments sont mis � jours selon la gravit� et le vente
  //les �l�ments disparaissent quand ils entrent en collision avec les feuille d'arbre ou le sol
  //entree:
  //  gravite nombre
  //  vent nombre
  //  arbre  objet qui contient l'arbre
  /*==========================================================*/
  {
    var yiel = [];
    for(var i in this.arrayFeuilleTombante)
    {
      this.arrayFeuilleTombante[i].force(vent*1, gravite*10);
      if (this.arrayFeuilleTombante[i].VaRentrerEnCollisionAvecLeSol(this.sol_hauteur))
      {
        this.arrayFeuilleTombante[i].annuleForce();
        setTimeout(function(elemMeteo,elemFeuille){
          elemMeteo.removeChild(elemFeuille);
        },30000,this.elemMeteo,this.arrayFeuilleTombante[i].elemSVG);
      }
      else
      {
        yiel.push(this.arrayFeuilleTombante[i]);
      }

      this.arrayFeuilleTombante[i].ajoute_deplacement_non_lineeaire(true, true, false);
      this.arrayFeuilleTombante[i].move();
      this.arrayFeuilleTombante[i].MiseAJour_element_svg();
    }
    this.arrayFeuilleTombante=yiel;
  };  
}
