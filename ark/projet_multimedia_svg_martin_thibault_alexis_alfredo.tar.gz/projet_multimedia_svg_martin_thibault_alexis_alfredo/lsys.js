/*******************************************************************************************************/
/*                                                                                                     */
/*  Fichier....................:  lsys.js                                                              */
/*  Type.......................:  Classe Javascript                                                    */
/*  Titre......................:  lsys                .                                                */
/*  Auteur.....................:  Martin Robinson                                                      */
/*                                Thibault Podevin                                                     */
/*                                Alexis Caron                                                         */
/*                                Alfredo Toyo                                                         */
/*  Copyright..................:  Cégep de Sherbrooke, all left free                                   */
/*  Date de création...........:  2013-10-19                                                           */
/*  Date de mise en production.:  2013-11-04                                                           */
/*                                                                                                     */
/*******************************************************************************************************/
/*  MODIFICATIONS                                                                                      */
/*  DATE       : PAR               : DESCRIPTION DES MODIFICATIONS                                     */
/*                                                                                                     */
/*******************************************************************************************************/
/*                                                                                                     */
/*  - Gestion de la phisique sur des points                                                            */
/*                                                                                                     */
/*  En entrée: RIEN                                                                                    */
/*                                                                                                     */
/*  En sortie: Document XHTML dynamique envoyer par mail.                                              */
/*                                                                                                     */
/*******************************************************************************************************/

/*
http://en.wikipedia.org/wiki/L-system
Le Lindenmayer system est un langage récursif qui permet de définir le développement d'une plante
Un botaniste du meme nom à définit les regles en étudiant des champignon et des levures.
Cela consiste à plusieurs remplacement de string
*/

/**********************************************************/
function contient(array_associatif, lettre)
//verifie si le array associatif contient une lettre
/**********************************************************/
{
  for(key in array_associatif)
  {
    if(key === lettre)
    {
      return true;
    }
  }
  return false;
}

/**********************************************************/
function prochaine_regle(regle, regle_remplacement)
//retourne la prochaine regle selon certains regle de remplacement
//de donnee
/**********************************************************/
{
  var nouvelle_regle = "";
  for(var iterateur = 0; iterateur < regle.length; iterateur++)
  {
    if(contient(regle_remplacement,regle[iterateur]))
    {
      nouvelle_regle += regle_remplacement[regle[iterateur]];
    }
    else
    {
      nouvelle_regle += regle[iterateur];
    }
  }
  return nouvelle_regle;
}

/*******************************************************************************************************/
//quelque example d'arbre
/*******************************************************************************************************/

var cool_tree =
{
  "X" : "F[-X]F[−b]+X",//cool tree
  "b" : "F[-X]F[−b]+X",
  "F" : "FF"
};
var cool_tree_too =
{
  "X" : "F[-X]F[+++X][−Xb]+X",//cool tree too
  "F" : "FF"
};

var wheat_no_leaf =
{
   /*"F" : "F+F−F−F+F"*/
  "X" : "F-[[X]+X]+F[+FX]-X",//wheat no leaf
  "F" : "FF"
};

var wheat_leaf =
{
  "X" : "F-[[X]+X]+F[+bX]-X",//wheat leaf
  "F" : "FF",
  "b" : "FF"
};

var basic_tree = 
{
  "a" : "aa", //basic tree
  "b" : "a[-b]+b"
};

var pretty_balanced_tree = 
{
  "X" : "F[+X]F[-b]F[−X]+X",//pretty balanced tree
  "F" : "FF",
  "b" : "F[+X]F[-X]F[−X]+X"
};
