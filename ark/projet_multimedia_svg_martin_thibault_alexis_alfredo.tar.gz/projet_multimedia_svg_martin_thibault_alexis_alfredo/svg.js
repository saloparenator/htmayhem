/*******************************************************************************************************/
/*                                                                                                     */
/*  Fichier....................:  svg.js                                                               */
/*  Type.......................:  Classe Javascript                                                    */
/*  Titre......................:  Animation SVG       .                                                */
/*  Auteur.....................:  Martin Robinson                                                      */
/*                                Thibault Podevin                                                     */
/*                                Alexis Caron                                                         */
/*                                Alfredo Toyo                                                         */
/*  Copyright..................:  Cégep de Sherbrooke, all left free                                   */
/*  Date de création...........:  2013-10-19                                                           */
/*  Date de mise en production.:  2013-11-04                                                           */
/*                                                                                                     */
/*******************************************************************************************************/
/*  MODIFICATIONS                                                                                      */
/*  DATE       : PAR               : DESCRIPTION DES MODIFICATIONS                                     */
/*                                                                                                     */
/*******************************************************************************************************/
/*                                                                                                     */
/*  - Gestion de la phisique sur des points                                                            */
/*                                                                                                     */
/*  En entrée: RIEN                                                                                    */
/*                                                                                                     */
/*  En sortie: Document XHTML dynamique envoyer par mail.                                              */
/*                                                                                                     */
/*******************************************************************************************************/

/*******************************************************************************************************/
function ajoute_element_svg_au_point(parent, element_id)
/*******************************************************************************************************/
//ajoute des propriété svg à un objet point
//via l'inhéritance (http://en.wikipedia.org/wiki/Prototype-based_programming)
/*******************************************************************************************************/
{
  //element dom de la feuille svg
  parent.elemSVG = document.createElementNS('http://www.w3.org/2000/svg',"use");
  parent.elemSVG.setAttributeNS("http://www.w3.org/1999/xlink", "xlink:href", "#"+element_id);
  parent.angle = Math.PI;

  parent.tourne = function(angle)
  {
    parent.angle = angle;
  }

  /*------------------------------------------------------------------------*/
  parent.MiseAJour_element_svg = function ()
  /*------------------------------------------------------------------------*/
  //method show met à jour les attributs SVG par rapport au propriété de l`objet
  //nom à revoir
  /*------------------------------------------------------------------------*/
  {
    var cos_angle = -1*Math.cos(parent.angle);
    var sin_angle = -1*Math.sin(parent.angle);
    var matrix = "matrix("+cos_angle+","+sin_angle+","+(-1*sin_angle)+","+cos_angle+","+(parent.x)+","+(parent.y)+")";
    parent.elemSVG.setAttribute('transform', matrix);
    //parent.elemSVG.setAttribute("transform","translate("+this.x+"," +this.y+")");
  }
}

/*******************************************************************************************************/
function ajoute_svg_au_point(parent)
/*******************************************************************************************************/
//ajoute une branche SVg à un point d'arbre
//via l'inhéritance objet (http://en.wikipedia.org/wiki/Prototype-based_programming)
/*******************************************************************************************************/
{
  parent.update_svg = function ()
  {
    if (parent.update_tige!=null)
    {
      parent.update_tige();
    }
    if (parent.update_feuille!=null)
    {
      parent.update_feuille();
    }
  }
}

/*******************************************************************************************************/
function ajoute_tige_svg_au_point(parent)
/*******************************************************************************************************/
//ajoute la tige svg à un point d'un arbre
//via l'inhéritance objet (http://en.wikipedia.org/wiki/Prototype-based_programming)
/*******************************************************************************************************/
{
  ajoute_svg_au_point(parent);
  
  //element dom de la tige svg
  parent.elemTige = document.createElementNS('http://www.w3.org/2000/svg',"path");
  parent.elemTige.setAttribute("stroke", "brown");
  parent.elemTige.setAttribute("stroke-width", "1");
  parent.elemTige.setAttribute("fill", "none");
  
  
  /*------------------------------------------------------------------------*/
  parent.update_tige = function ()
  /*------------------------------------------------------------------------*/
  //method show met à jour les attributs SVG par rapport au propriété de l`objet
  //nom à revoir
  /*------------------------------------------------------------------------*/
  {
    //path
    if (parent.parent!=null)
    {
      var path = "M "+parent.x+" "+parent.y;
      var x1=parent.x;
      var y1=parent.y
      var x2=parent.parent.x - x1;
      var y2=parent.parent.y - y1;
      if(parent.parent.parent==null)
      {
        //dessine une ligne
        path = path + " l " + x2 +" "+ y2;
      }
      else
      {
        //dessine une courbe
        var x3=parent.parent.parent.x - x1;
        var y3=parent.parent.parent.y - y1;
        path = path + " q " + x2 + " " + y2 + " " + x3 + " " + y3;
      }
      parent.elemTige.setAttribute("d", path);
    }
  }

}

/*******************************************************************************************************/
function ajoute_feuille_svg_au_point(parent, elementid)
/*******************************************************************************************************/
//ajoute une feuille au bout d'une brance svg à un point d'arbre
//via l'inheritance objet (http://en.wikipedia.org/wiki/Prototype-based_programming)
/*******************************************************************************************************/
{
  ajoute_svg_au_point(parent);
  //element dom de la feuille svg
  parent.angle = Math.PI;
  parent.elemFeuille = document.createElementNS('http://www.w3.org/2000/svg',"use");
  parent.elemFeuille.setAttributeNS("http://www.w3.org/1999/xlink", "xlink:href", "#"+elementid);
  parent.elemFeuille.setAttribute("r", parent.r+"px");
  
  /*------------------------------------------------------------------------*/
  parent.update_feuille = function ()
  /*------------------------------------------------------------------------*/
  //method show met à jour les attributs SVG par rapport au propriété de l`objet
  //nom à revoir
  /*------------------------------------------------------------------------*/
  {
    if(parent.parent!=null && parent.parent.parent!=null)
    {
      var delta_x = parent.parent.x-parent.parent.parent.x;
      var delta_y = parent.parent.y-parent.parent.parent.y;
      parent.angle = Math.PI/2+Math.atan2(delta_y,delta_x);
      var cos_angle = -1*Math.cos(parent.angle);
      var sin_angle = -1*Math.sin(parent.angle);
      var matrix = "matrix("+cos_angle+","+sin_angle+","+(-1*sin_angle)+","+cos_angle+","+(parent.x)+","+(parent.y)+")";
      parent.elemFeuille.setAttribute('transform', matrix);
    }
  }
}

/*******************************************************************************************************/
function ajoute_svg_a_arbre(arbre, elementFeuille)
/*******************************************************************************************************/
//ajoute des éléments svg à tout les point d'un arbre
/*******************************************************************************************************/
{
  var groupe_arbre = document.getElementById("groupe_arbre");
  var groupe_feuille = document.getElementById("groupe_feuille");

  for(var iterateur = 0; iterateur < arbre.points.length; iterateur++)
  {
    ajoute_tige_svg_au_point(arbre.points[iterateur]);
    groupe_arbre.appendChild(arbre.points[iterateur].elemTige);
    if(arbre.points[iterateur].type == 'b')
    {
      //if not hivers
      ajoute_feuille_svg_au_point(arbre.points[iterateur],elementFeuille);
      groupe_feuille.appendChild(arbre.points[iterateur].elemFeuille);
    }
    arbre.points[iterateur].update_svg();
  }
}
