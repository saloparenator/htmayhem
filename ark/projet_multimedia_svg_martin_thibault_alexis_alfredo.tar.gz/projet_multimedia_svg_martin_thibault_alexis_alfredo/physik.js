/*******************************************************************************************************/
/*                                                                                                     */
/*  Fichier....................:  physik.js                                                            */
/*  Type.......................:  Classe Javascript                                                    */
/*  Titre......................:  simulation physik   .                                                */
/*  Auteur.....................:  Martin Robinson                                                      */
/*                                Thibault Podevin                                                     */
/*                                Alexis Caron                                                         */
/*                                Alfredo Toyo                                                         */
/*  Copyright..................:  Cégep de Sherbrooke, all left free                                   */
/*  Date de création...........:  2013-10-19                                                           */
/*  Date de mise en production.:  2013-11-04                                                           */
/*                                                                                                     */
/*******************************************************************************************************/
/*  MODIFICATIONS                                                                                      */
/*  DATE       : PAR               : DESCRIPTION DES MODIFICATIONS                                     */
/*                                                                                                     */
/*******************************************************************************************************/
/*                                                                                                     */
/*  - Gestion de la phisique sur des points                                                            */
/*                                                                                                     */
/*  En entrée: RIEN                                                                                    */
/*                                                                                                     */
/*  En sortie: Document XHTML dynamique envoyer par mail.                                              */
/*                                                                                                     */
/*******************************************************************************************************/



/*******************************************************************************************************\
|*****************************************FONCTIONS*****************************************************|
\*******************************************************************************************************/

/*-----------------------------------------------------------------------------------------------------*/
/*                                                                                                     */
/* Cette fonction ajoute de la phisique a un objet <<Point>>                                           */
/*                                                                                                     */
/* Prend en parametre le point a apliquer la phisique dessu                                            */
/*-----------------------------------------------------------------------------------------------------*/
function ajoutePhysiqueAuPoint(parent)
/*-----------------------------------------------------------------------------------------------------*/
{
  //ajout les vecteurs de directions au parent
  parent.vx = 0;
  parent.vy = 0;
  parent.sin_change = 0.03;
  parent.frequanceBase = 1.5;
  parent.frequance = (Math.random()*3)-parent.frequanceBase;
  
  /*--------------------------------------------------------*/
  parent.VaRentrerEnCollision = function(autreparent)
  /*--------------------------------------------------------*/
  //Cette fonction retourne si oui ou non le parent va rentrer
  //en Collision avec un autre parent
  //Ne prend en entrer que l'autre parent et retourne un boolean
  /*--------------------------------------------------------*/
  {
    var collision = false;
    var vx = (parent.vx>1 ? 1 : (parent.vx<-1 ? -1 : parent.vx));
    var vy = (parent.vy>1 ? 1 : (parent.vy<-1 ? -1 : parent.vy));
    var deplacementX = parent.x + vx;
    var deplacementY = parent.y + vy;
    if(autreparent != null)
    {
      var deltaX = deplacementX - autreparent.x;
      var deltaY = deplacementY - autreparent.y;

      collision = Math.pow(parent.deltaX + parent.deltaY, 2) < Math.pow(parent.r + autreparent.r, 2);
    }
    
    return collision;
  }


  /*--------------------------------------------------------*/
  parent.entreEnCollision = function(autreparent)
  /*--------------------------------------------------------*/
  //Cette fonction retourne si oui ou non le parent entre
  //en Collision avec un autre parent
  //Ne prend en entrer que l'autre parent et retourne un boolean
  /*--------------------------------------------------------*/
  {
    var collision = false;
    var parentFuturX = parent.x;
    var parentFuturY = parent.y;
    if(autreparent != null)
    {
      var deltaX = parentFuturX - autreparent.x;
      var deltaY = parentFuturY - autreparent.y;
      var radius = parent.r + autreparent.r;

      collision = Math.pow(deltaX,2) + Math.pow(deltaY, 2) < Math.pow(radius, 2);
    }

    return collision;
  }

  /*-----------------------------------------------------------*/
  parent.VaRentrerEnCollisionAvecLeSol = function(hauteurFenetre)
  /*-----------------------------------------------------------*/
  //
  //Verifie si un parent va entrer en collision avec le sol
  //
  /*-----------------------------------------------------------*/
  {
    var vy = (parent.vy>1 ? 1 : (parent.vy<-1 ? -1 : parent.vy));
    var deplacementY = parent.y + vy;
    return deplacementY > hauteurFenetre;
  }
  
  /*-----------------------------------------------------------*/
  parent.force = function(deplacementX, deplacementY)
  /*-----------------------------------------------------------*/
  //
  //Modifie la force (deplacement) qui emule la gravite
  //
  /*-----------------------------------------------------------*/
  {
    parent.vx += deplacementX;
    parent.vy += deplacementY;
  }

  /*-----------------------------------------------------------*/
  parent.annuleForce = function ()
  /*-----------------------------------------------------------*/
  //
  //Anulle toutes force appliquer sur l'objet
  //
  /*-----------------------------------------------------------*/
  {
    parent.vx = 0;
    parent.vy = 0;
  }
  
  /*-----------------------------------------------------------*/
  parent.move = function()
  /*-----------------------------------------------------------*/
  //
  //Applique le deplacement. Effectue le "refresh" de l'animation
  //
  /*-----------------------------------------------------------*/
  {
    if(parent.vx > 1)
	parent.vx = 1;
    else if(parent.vx < -1)
	parent.vx = -1;
    if(parent.vy > 1)
	parent.vy = 1;
    else if(parent.vy < -1)
	parent.vy = -1;
    parent.x += parent.vx;
    parent.y += parent.vy;
  }

  /*-----------------------------------------------------------*/
  parent.moveTo = function(deplacementX, deplacementY)
  /*-----------------------------------------------------------*/
  //
  //Fais le deplacement en fonction d'une direction donnee.
  //Utiliser plus en mode de debug
  //
  /*-----------------------------------------------------------*/
  {
    if(parent.vx > 1)
	parent.vx = 1;
    else if(parent.vx < -1)
	parent.vx = -1;
    if(parent.vy > 1)
	parent.vy = 1;
    else if(parent.vy < -1)
	parent.vy = -1;
    parent.x += parent.vx * deplacementX;
    parent.y += parent.vy * deplacementY;
  }

  //-------------------------------------------------------------------------*/
  parent.ajoute_deplacement_non_lineeaire = function(action, sensX, sensY)
  //-------------------------------------------------------------------------*/
  //
  //Applique un mouvement sinuzoidale au mouvement.
  //action est un flag qui active le mouvement sinuzoidale
  //sensX est un flag qui Set le deplacement Horizontalement
  //sensY est un flag qui Set le deplacement Verticalement
  //
  /*-------------------------------------------------------------------------*/
  {
    parent.amplitude = 1;
 
    parent.sinus = action;
  
    if(action && parent.vx != 0)
    {
      if(parent.frequance > 1.5)
      {
        parent.frequance = 1.5;//goingUp = false;
        parent.sin_change *= -1;
      }
      else if(parent.frequance < -1.5)
      {
        parent.frequance = -1.5;//goingUp = true;
        parent.sin_change *= -1;
      }
      parent.frequance += parent.sin_change;
      if(sensX)
      {
        parent.x = ((parent.amplitude*Math.sin(parent.frequance))+parent.x);
      }
      else if(sensY)
      {
        parent.y = ((parent.amplitude*Math.sin(parent.frequance))+parent.y);
      }
      else if(sensY == true && sensX == true)
      {
        parent.y = ((parent.amplitude*Math.sin(parent.frequance))+parent.y);
        parent.x = ((parent.amplitude*Math.sin(parent.frequance))+parent.x);
      }
    }
  }
  
}

/*-------------------------------------------------------------*/
function spring(pointA, pointB)
/*-------------------------------------------------------------*/
//
//Applique une spring entre 2 points
//
/*-------------------------------------------------------------*/
{
  var ratio = 0.07;
  this.pointA = pointA;
  this.pointB = pointB;
  this.spring = ratio;
  this.longeur = Math.sqrt(Math.pow(this.pointA.x - this.pointB.x, 2) + Math.pow(this.pointA.y - this.pointB.y, 2));

  this.pull = function()
  {
    var deltaX = this.pointB.x - this.pointA.x;
    var deltaY = this.pointB.y - this.pointA.y;
    var length = Math.sqrt(Math.pow(deltaX,2) + Math.pow(deltaY,2));
    var force = ((length - this.longeur) * this.spring)/2;
    this.pointA.vx += deltaX*force;
    this.pointA.vy += deltaY*force;
    this.pointB.vx -= deltaX*force;
    this.pointB.vy -= deltaY*force;
  }
}

/*-------------------------------------------------------------*/
function ajoute_physique_a_arbre(arbre)
/*-------------------------------------------------------------*/
//
//Cette fonction va parcourir le graph de point que constitue l'arbre
//et va appliquer les elements de phisique a chacun d'entre eux
//
/*-------------------------------------------------------------*/
{
  for(var iterateur = 0; iterateur < arbre.points.length; iterateur++)
  {
    ajoutePhysiqueAuPoint(arbre.points[iterateur]);
    if(arbre.points[iterateur].parent != null)
    {
      arbre.springs.push(new spring(arbre.points[iterateur], arbre.points[iterateur].parent));
      if(arbre.points[iterateur].parent.parent != null)
      {
        arbre.springs.push(new spring(arbre.points[iterateur], arbre.points[iterateur].parent.parent));
      }
    }
  }
}
