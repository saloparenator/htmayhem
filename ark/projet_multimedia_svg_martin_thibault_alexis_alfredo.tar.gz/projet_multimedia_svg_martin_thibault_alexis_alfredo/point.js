/*******************************************************************************************************/
/*                                                                                                     */
/*  Fichier....................:  point.js                                                             */
/*  Type.......................:  Classe Javascript                                                    */
/*  Titre......................:  point               .                                                */
/*  Auteur.....................:  Martin Robinson                                                      */
/*                                Thibault Podevin                                                     */
/*                                Alexis Caron                                                         */
/*                                Alfredo Toyo                                                         */
/*  Copyright..................:  Cégep de Sherbrooke, all left free                                   */
/*  Date de création...........:  2013-10-19                                                           */
/*  Date de mise en production.:  2013-11-04                                                           */
/*                                                                                                     */
/*******************************************************************************************************/
/*  MODIFICATIONS                                                                                      */
/*  DATE       : PAR               : DESCRIPTION DES MODIFICATIONS                                     */
/*                                                                                                     */
/*******************************************************************************************************/
/*                                                                                                     */
/*  - Gestion de la phisique sur des points                                                            */
/*                                                                                                     */
/*  En entrée: RIEN                                                                                    */
/*                                                                                                     */
/*  En sortie: Document XHTML dynamique envoyer par mail.                                              */
/*                                                                                                     */
/*******************************************************************************************************/


/*__________________________________________________________________________*/
function point(id,x,y,angle,r,type,precedent,parent)
/*__________________________________________________________________________*/
//objet de point pour le visuel
//le parent permet de déterminer avec quelles point il fera sa courbe
//visuel à travailler
//le constructeur s`attend à des coordonné, un rayon pour la taille
//et un parent qui peut etre null
/*__________________________________________________________________________*/
{
  //propriete
  this.id = id;
  this.x = x;
  this.y = y;
  this.angle = angle;
  this.r=r;
  this.type = type;
  this.precedent = precedent;
  this.parent = parent;
}
