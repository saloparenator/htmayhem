/*******************************************************************************************************/
/*                                                                                                     */
/*  Fichier....................:  arbre.js                                                             */
/*  Type.......................:  Classe Javascript                                                    */
/*  Titre......................:  arbre               .                                                */
/*  Auteur.....................:  Martin Robinson                                                      */
/*                                Thibault Podevin                                                     */
/*                                Alexis Caron                                                         */
/*                                Alfredo Toyo                                                         */
/*  Copyright..................:  C�gep de Sherbrooke, all left free                                   */
/*  Date de cr�ation...........:  2013-10-19                                                           */
/*  Date de mise en production.:  2013-11-04                                                           */
/*                                                                                                     */
/*******************************************************************************************************/
/*  MODIFICATIONS                                                                                      */
/*  DATE       : PAR               : DESCRIPTION DES MODIFICATIONS                                     */
/*                                                                                                     */
/*******************************************************************************************************/
/*                                                                                                     */
/*  - Gestion de la phisique sur des points                                                            */
/*                                                                                                     */
/*  En entr�e: RIEN                                                                                    */
/*                                                                                                     */
/*  En sortie: Document XHTML dynamique envoyer par mail.                                              */
/*                                                                                                     */
/*******************************************************************************************************/

/*******************************************************************************************************/
function ArbrePoint(lsystem, position)
/*******************************************************************************************************/
//Objet arbre
//cet objet compose l'arbre sous forme de point interconnect�
//
//construction
//  lsystem sous forme de string
//  position  sous form d'un liste associative de coordonn� {'x' : 0, 'y' : 0}
/*******************************************************************************************************/
{
  this.scalaire_arbre = 15;
  this.points = genere_LSystem(lsystem,0.5,-Math.PI*0.5, this.scalaire_arbre, position['x'], position['y']);
  this.springs = [];
  this.feuille = [];

  for (var i in this.points)
  {
    if (this.points[i].type=='b')
    {
      this.feuille.push(this.points[i]);
    }
  }

  /*--------------------------------------------------------*/  
  this.collisionFeuille = function(pointA)
  /*--------------------------------------------------------*/
  //detection de collision entre un point
  //et toutes les feuilles de l'arbre
  //entree
  //  pointA en tan qu'objet point
  //sortie
  //  booleen si le point est entr� en collision
  /*--------------------------------------------------------*/
  {
    for (var i in this.feuille)
    {
      if (pointA.entreEnCollision(this.feuille[i]))
      {
        return true;
      }
    }
    return false;
  }
  
  /*--------------------------------------------------------*/
  this.vecteurForce = function(forceX, forceY)
  /*--------------------------------------------------------*/
  //Cette fonction change le vecteur de force, appliquant
  //une force en X ou Y sur les points de l'arbre
  /*--------------------------------------------------------*/
  {
    for(var iterateur = 2; iterateur < this.points.length; iterateur++)
    {
       this.points[iterateur].force(forceX,forceY);//0.0001
       if(!this.points[iterateur].VaRentrerEnCollisionAvecLeSol(position['y']))
       { 
         this.points[iterateur].move();
       }
       else
       {
         this.points[iterateur].annuleForce();
       }
       this.points[iterateur].update_svg();
    }

    for(var iterateur = 0; iterateur < this.springs.length; iterateur++)
    {
      this.springs[iterateur].pull();
    }
  }
}
