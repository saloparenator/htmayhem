/*******************************************************************************************************/
/*                                                                                                     */
/*  Fichier....................:  robot.js                                                             */
/*  Type.......................:  Classe Javascript                                                    */
/*  Titre......................:  robot               .                                                */
/*  Auteur.....................:  Martin Robinson                                                      */
/*                                Thibault Podevin                                                     */
/*                                Alexis Caron                                                         */
/*                                Alfredo Toyo                                                         */
/*  Copyright..................:  Cégep de Sherbrooke, all left free                                   */
/*  Date de création...........:  2013-10-19                                                           */
/*  Date de mise en production.:  2013-11-04                                                           */
/*                                                                                                     */
/*******************************************************************************************************/
/*  MODIFICATIONS                                                                                      */
/*  DATE       : PAR               : DESCRIPTION DES MODIFICATIONS                                     */
/*                                                                                                     */
/*******************************************************************************************************/
/*                                                                                                     */
/*  - Gestion de la phisique sur des points                                                            */
/*                                                                                                     */
/*  En entrée: RIEN                                                                                    */
/*                                                                                                     */
/*  En sortie: Document XHTML dynamique envoyer par mail.                                              */
/*                                                                                                     */
/*******************************************************************************************************/

/**********************************************************/
function genere_LSystem(var_string, degrees, degrees_de_depart, scalaire, depart_x, depart_y)
//genere les points du LSystem selon une regle
/**********************************************************/
{
  var point_LSystem = [];
  var precedent = [0];
  var iterator = 0;
  
  var present_precedent = 0;
  var present_id = 1;
  var present_angle = degrees_de_depart;
  var modificateur_angle = degrees;
  var present_x = depart_x;
  var present_y = depart_y;
  point_LSystem.push(new point(0, depart_x, depart_y, Math.PI, 0, 'a', 0, null));

  while(iterator < var_string.length)
  {
    switch(var_string[iterator])
    {
      case 'a': case 'F':
        //branche + avancer
        present_x = present_x + Math.round(Math.cos(present_angle)*scalaire);
        present_y = present_y + Math.round(Math.sin(present_angle)*scalaire);
      case 'b':
        //avancer
        point_LSystem.push(new point(present_id,present_x,present_y,present_angle,10,var_string[iterator],present_precedent,point_LSystem[present_precedent]));
        present_precedent = present_id;
        present_id++;
        break;
      case '+':
        //augmenter l'angle
        present_angle += modificateur_angle;
        break;
      case '-':
        //reduire l'angle
        present_angle -= modificateur_angle;
        break;
      case '[':
        //stock le point courant
        precedent.push(present_id-1);
        break;
      case ']':
        //retour au point précédent
        present_angle = point_LSystem[precedent[precedent.length-1]].angle;
        present_x = point_LSystem[precedent[precedent.length-1]].x;
        present_y = point_LSystem[precedent[precedent.length-1]].y;
        present_precedent = point_LSystem[precedent[precedent.length-1]].id;
        precedent.pop();
        break;
      default :
        break;
    }
    iterator++;
  }
  return point_LSystem;
}
