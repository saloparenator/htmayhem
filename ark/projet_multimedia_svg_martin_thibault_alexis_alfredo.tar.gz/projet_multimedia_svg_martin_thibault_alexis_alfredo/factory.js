/*******************************************************************************************************/
/*                                                                                                     */
/*  Fichier....................:  factory.js                                                           */
/*  Type.......................:  Classe Javascript                                                    */
/*  Titre......................:  factory             .                                                */
/*  Auteur.....................:  Martin Robinson                                                      */
/*                                Thibault Podevin                                                     */
/*                                Alexis Caron                                                         */
/*                                Alfredo Toyo                                                         */
/*  Copyright..................:  C�gep de Sherbrooke, all left free                                   */
/*  Date de cr�ation...........:  2013-10-19                                                           */
/*  Date de mise en production.:  2013-11-04                                                           */
/*                                                                                                     */
/*******************************************************************************************************/
/*  MODIFICATIONS                                                                                      */
/*  DATE       : PAR               : DESCRIPTION DES MODIFICATIONS                                     */
/*                                                                                                     */
/*******************************************************************************************************/
/*                                                                                                     */
/*  - Gestion de la phisique sur des points                                                            */
/*                                                                                                     */
/*  En entr�e: RIEN                                                                                    */
/*                                                                                                     */
/*  En sortie: Document XHTML dynamique envoyer par mail.                                              */
/*                                                                                                     */
/*******************************************************************************************************/

/*
//http://en.wikipedia.org/wiki/Factory_method_pattern
//il arrive souvent qu'un objet ou un collection d'objet du meme abstract ait beaucoup de complexit�
//� l'initialisation.
//de gros constructeur avec beaucoup de param�tre pour initialiser rend l'objet difficile � utiliser
//Pour ce cas il y a un design pattern appeler le Factory method.
//cela consiste � avoir un ou plusieurs fonction qui retourne une instance d'objet initialise selon
//certain crit�re courant.
//De cette fa�ons nous r�duisont le nombre de param�tre � fournire et nous abstracton tout le constructeur
//Aussi nous pouvont donner un nom significatif � la factory qui repr�sente mieux l'objet r�sultant
//qu'un constructeur surcharg�
*/

/*******************************************************************************************************/
function arbreFactory(depart, remplacement, nb_iteration)
/*******************************************************************************************************/
//procede � l'expansion du l-system
//entre:
//  depart         une chaine de charactere representant l'arbre sous sa form original
//  remplacement   une liste associative qui represente les regles d'expansion de l'Arbre
//  nb_iteration   un nombre enumerant le nombre de fois que l'Arbre va grandir
/*******************************************************************************************************/
{
  pousse = depart;
  for(var iterateur = 0; iterateur < nb_iteration; iterateur++)
  {
    pousse = prochaine_regle(pousse,remplacement);
  }
  return pousse;
}

/*******************************************************************************************************/
function eteFactory(pousse, tempsSecond)
/*******************************************************************************************************/
//factory d'ete
//configure la scene pour repr�senter l'�t�
//entre:
//  pousse,       chaine de caract�re representant l'Arbre
//  tempsSeconde  heur de la journ� en seconde depuis minuit
/*******************************************************************************************************/
{
  var ecran_largeur = prendreEcranLargeur();
  var ecran_hauteur = prendreEcranHauteur();

  var arbre = new ArbrePoint(pousse, {'x':ecran_largeur/2, 'y':ecran_hauteur-80});
  var arrierePlan = new ArrierePlan(ecran_largeur, ecran_hauteur,"rgb(0,123,12)",tempsSecond, elemsSon);
  
  var elemsSon = [];
  elemsSon.push(document.getElementById('gouttes1'));
  elemsSon.push(document.getElementById('gouttes2'));
  elemsSon.push(document.getElementById('gouttes3'));
  elemsSon.push(document.getElementById('gouttes4'));
  elemsSon.push(document.getElementById('gouttes5'));
  elemsSon.push(document.getElementById('gouttes6'));

  var nuage = new Nuage(ecran_largeur, ecran_hauteur, -50,40, "goutte",true,elemsSon);
  
  ajoute_physique_a_arbre(arbre);
  ajoute_svg_a_arbre(arbre,"feuilleverte");
  arrierePlan.afficherA(document.getElementById("arrierePlan"));
  nuage.afficherA(document.getElementById("meteo"));

  setInterval(function() {
    arbre.vecteurForce(prendreInputVent()*0.001, prendreInputGravite()*0.0007)
  },33);
  
  setInterval(function(){
    arrierePlan.iterate();
  },1000);
  
  setInterval(function(){
    nuage.deplacementNuage(prendreInputVent()*0.5);
  },150);
  
  setInterval(function(){
    nuage.tombe(prendreInputGravite(), prendreInputVent(),arbre);
  },50);
  
  setInterval(function(){
    nuage.degoute();
  },700);
}

/*******************************************************************************************************/
function automneFactory(pousse, tempsSecond)
/*******************************************************************************************************/
//factory d'automne
//configure la scene pour repr�senter l'automne
//entre:
//  pousse,       chaine de caract�re representant l'Arbre
//  tempsSeconde  heur de la journ� en seconde depuis minuit
/*******************************************************************************************************/
{
  var ecran_largeur = prendreEcranLargeur();
  var ecran_hauteur = prendreEcranHauteur();

  var arbre = new ArbrePoint(pousse, {'x':ecran_largeur/2, 'y':ecran_hauteur-80});
  var arrierePlan = new ArrierePlan(ecran_largeur, ecran_hauteur,"rgb(224,192,64)", tempsSecond);

  var elemsSon = [];
  elemsSon.push(document.getElementById('feuille1'));
  elemsSon.push(document.getElementById('feuille2'));
  elemsSon.push(document.getElementById('feuille3'));
  elemsSon.push(document.getElementById('feuille4'));
  elemsSon.push(document.getElementById('feuille5'));

  var feuilleTombante = new FeuilleTombante(ecran_largeur, ecran_hauteur, elemsSon);

  ajoute_physique_a_arbre(arbre);
  ajoute_svg_a_arbre(arbre,"feuillerouge");
  arrierePlan.afficherA(document.getElementById("arrierePlan"));
  feuilleTombante.afficherA(document.getElementById("meteo"));
  
  setInterval(function() {
    arbre.vecteurForce(prendreInputVent()*0.001, prendreInputGravite()*0.0007)
  },33);
  
  setInterval(function(){
    arrierePlan.iterate();
  },1000);
  
  setInterval(function(){
    feuilleTombante.tombe(prendreInputGravite(), prendreInputVent());
  },5);
  
  setInterval(function(){
    feuilleTombante.degoute(arbre);
  },1500);
}

/*******************************************************************************************************/
function hiverFactory(pousse, tempsSecond)
/*******************************************************************************************************/
//factory d'hiver
//configure la scene pour repr�senter l'hiver
//entre:
//  pousse,       chaine de caract�re representant l'Arbre
//  tempsSeconde  heur de la journ� en seconde depuis minuit
/*******************************************************************************************************/
{
  var ecran_largeur = prendreEcranLargeur();
  var ecran_hauteur = prendreEcranHauteur();

  var arbre = new ArbrePoint(pousse, {'x':ecran_largeur/2, 'y':ecran_hauteur-80});
  var arrierePlan = new ArrierePlan(ecran_largeur, ecran_hauteur,"rgb(255,255,255)", tempsSecond);

  var elemsSon = [];
  elemsSon.push(document.getElementById('neige1'));
  elemsSon.push(document.getElementById('neige2'));
  elemsSon.push(document.getElementById('neige3'));
  elemsSon.push(document.getElementById('neige4'));
  elemsSon.push(document.getElementById('neige5'));
  elemsSon.push(document.getElementById('neige6'));
  
  var nuage = new Nuage(ecran_largeur, ecran_hauteur, -50,40, "flocon_neige",false, elemsSon);

  
  ajoute_physique_a_arbre(arbre);
  ajoute_svg_a_arbre(arbre,"pasdefeuille");
  arrierePlan.afficherA(document.getElementById("arrierePlan"));
  nuage.afficherA(document.getElementById("meteo"));

  setInterval(function() {
    arbre.vecteurForce(prendreInputVent()*0.001, prendreInputGravite()*0.0007)
  },33);
  
  setInterval(function(){
    arrierePlan.iterate();
  },1000);
  

  setInterval(function(){
    nuage.deplacementNuage(prendreInputVent()*0.5);
  },150);
  
  setInterval(function(){
    nuage.tombe(prendreInputGravite(), prendreInputVent(),arbre);
  },100);
  
  setInterval(function(){
    nuage.degoute();
  },700);
}

/*******************************************************************************************************/
function printempFactory(pousse, tempsSecond)
/*******************************************************************************************************/
//factory de printemp
//configure la scene pour repr�senter le printemp
//entre:
//  pousse,       chaine de caract�re representant l'Arbre
//  tempsSeconde  heur de la journ� en seconde depuis minuit
/*******************************************************************************************************/
{
  var ecran_largeur = prendreEcranLargeur();
  var ecran_hauteur = prendreEcranHauteur();

  var arbre = new ArbrePoint(pousse, {'x':ecran_largeur/2, 'y':ecran_hauteur-80});
  var arrierePlan = new ArrierePlan(ecran_largeur, ecran_hauteur,"rgb(128,255,128)", tempsSecond);

  var elemsSon = [];
  elemsSon.push(document.getElementById('pollen1'));
  elemsSon.push(document.getElementById('pollen2'));
  elemsSon.push(document.getElementById('pollen3'));
  elemsSon.push(document.getElementById('pollen4'));
  elemsSon.push(document.getElementById('pollen5'));

  var polenisateur = new Polenisateur(ecran_largeur, ecran_hauteur, elemsSon);
  
  ajoute_physique_a_arbre(arbre);
  ajoute_svg_a_arbre(arbre,"fleur");
  arrierePlan.afficherA(document.getElementById("arrierePlan"));
  polenisateur.afficherA(document.getElementById("meteo"));
  
  setInterval(function() {
    arbre.vecteurForce(prendreInputVent()*0.001, prendreInputGravite()*0.0007)
  },33);
  
  setInterval(function(){
    arrierePlan.iterate();
  },1000);
  
  setInterval(function(){
    polenisateur.tombe(prendreInputGravite(), prendreInputVent(),arbre);
  },30);
  
  setInterval(function(){
    polenisateur.degoute();
  },1500);
}

/*******************************************************************************************************/
function saisonFactory(num_saison)
/*******************************************************************************************************/
//execute une factory selon le numero de saison
/*******************************************************************************************************/
{
  saisonLst = 
  [
    eteFactory,
    automneFactory,
    hiverFactory,
    printempFactory
  ];
  return saisonLst[num_saison%4];
}
